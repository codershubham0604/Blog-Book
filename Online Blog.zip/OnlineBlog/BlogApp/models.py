from django.db import models

# Create your models here.
class Users(models.Model):
	userid=models.CharField(max_length=20)
	name=models.CharField(max_length=20)
	city=models.CharField(max_length=20)
	email=models.CharField(max_length=20)
	Phone=models.CharField(max_length=20)
	class Meta:
		db_table='Users'



class Subject(models.Model):
	subjectid=models.CharField(max_length=20)
	subjectname=models.CharField(max_length=20)
	stream=models.CharField(max_length=20)

	class Meta:
		db_table='Subject'





class Blog(models.Model):
	blogid=models.CharField(max_length=20)
	userid=models.CharField(max_length=20)
	subjectid=models.CharField(max_length=20)
	blogtext=models.CharField(max_length=20)
	decreption=models.CharField(max_length=20)
	rating=models.CharField(max_length=20)

	class Meta:
		db_table='Blog'





class Rating(models.Model):
	blogid=models.CharField(max_length=20)
	userid=models.CharField(max_length=20)
	rating=models.CharField(max_length=20)

	class Meta:
		db_table='Rating'



class Contact(models.Model):
	email=models.CharField(max_length=20)
	name=models.CharField(max_length=20)
	subject=models.CharField(max_length=20)
	massage=models.CharField(max_length=20)

	class Meta:
		db_table='Contact'





class FilesAdminBtech(models.Model):
	adminupload=models.FileField(upload_to='media')
	title=models.CharField(max_length=50)


	def __str__(self):
		return self.title



class FilesAdminDiploma(models.Model):
	admiinupload=models.FileField(upload_to='media')
	title=models.CharField(max_length=50)


	def __str__(self):
		return self.title





