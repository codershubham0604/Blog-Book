from django.contrib import admin
from .models import FilesAdminBtech
from .models import FilesAdminDiploma


# Register your models here.

admin.site.register(FilesAdminBtech)

admin.site.register(FilesAdminDiploma)






