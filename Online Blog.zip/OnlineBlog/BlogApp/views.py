from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import FilesAdminBtech
from django.views.decorators.csrf import csrf_exempt
from BlogApp.models import *



# Create your views here.


def usersinput(request):
	return render(request,'usersinput.html')

@csrf_exempt
def datasave(request):
	a=request.POST.get("uid")
	b=request.POST.get("uname")
	c=request.POST.get("ucity")
	d=request.POST.get("uemail")
	e=request.POST.get("uphone")
	obj=Users(userid=a,name=b,city=c,email=d,Phone=e,)
	obj.save()
	return HttpResponse("Congratulation Your Record has Saved.  Thank You.  Have A Nice Day")


def subject(request):
	return render(request,'subject.html')

@csrf_exempt
def datasave1(request):
	a=request.POST.get("sid")
	b=request.POST.get("sname")
	c=request.POST.get("sstream")
	obj=Subject(subjectid=a,subjectname=b,stream=c,)
	obj.save()
	return HttpResponse("Congratulation Your Record has Saved.  Thank You.  Have A Nice Day")




def blog(request):
	return render(request,'blog.html')

@csrf_exempt
def datasave2(request):
	a=request.POST.get("blogid")
	b=request.POST.get("userid")
	c=request.POST.get("subjectid")
	d=request.POST.get("blogtext")
	e=request.POST.get("decreption")
	f=request.POST.get("rating")
	obj=Blog(blogid=a,userid=b,subjectid=c,blogtext=d,decreption=e,rating=f,)
	obj.save()
	return HttpResponse("Congratulation Your Record has Saved. Thank You Have A Nice Day")







def rating(request):
	return render(request,'rating.html')

@csrf_exempt
def datasave3(request):
	a=request.POST.get("blogid")
	b=request.POST.get("userid")
	c=request.POST.get("rating")
	obj=Rating(blogid=a,userid=b,rating=c,)
	obj.save()
	return HttpResponse("Congratulation Your Record has Saved.  Thank You.  Have A Nice Day")



def contact(request):
	return render(request,'contact.html')

@csrf_exempt
def datasave4(request):
	
	a=request.POST.get("Email")
	b=request.POST.get("name")
	c=request.POST.get("subject")
	e=request.POST.get("massage")
	
	obj=Contact(email=a,name=b,subject=c,massage=e,)
	obj.save()
	return HttpResponse("Congratulation Your Record has Saved.  Thank You.  Have A Nice Day")











def blogshow(request):
	obj=Blog.objects.all()
	msg="<table width='100%' border='5'>"
	msg=msg+"<h1>All Blog's</h1>"
	msg=msg+"<tr>"
	msg=msg+"<td>blogid</td>"
	msg=msg+"<td>userid</td>"
	msg=msg+"<td>subjectid</td>"
	msg=msg+"<td>blogtext</td>"
	msg=msg+"<td>decreption</td>"
	msg=msg+"<td>rating</td>"
	msg=msg+"</tr>"
	for res in obj:
		msg=msg+"<tr>"
		msg=msg+"<td>"+res.blogid+"</td>"
		msg=msg+"<td>"+res.userid+"</td>"
		msg=msg+"<td>"+res.subjectid+"</td>"
		msg=msg+"<td>"+res.blogtext+"</td>"
		msg=msg+"<td>"+res.decreption+"</td>"
		msg=msg+"<td>"+res.rating+"</td>"
		msg=msg+"</tr>"
	msg=msg+"</table>"
	return HttpResponse(msg)





def home(request):
	return render(request,'home.html')


def index(request):
	return render(request,'index.html')

def btech(request):
	return render(request,'btech.html')
def diploma(request):
	return render(request,'diploma.html')
def bca(request):
	return render(request,'bca.html')
def bsc(request):
	return render(request,'bsc.html')
def iti(request):
	return render(request,'iti.html')
def mbbs(request):
	return render(request,'mbbs.html')
def mca(request):
	return render(request,'mca.html')
def mtech(request):
	return render(request,'mtech.html')
def bpharma(request):
	return render(request,'bpharma.html')
def study(request):
	return render(request,'study.html')
def about(request):
	return render(request,'about.html')
def contact(request):
	return render(request,'contact.html')
def webtech(request):
	return render(request,'web tech.html')
def database(request):
	return render(request,'database.html')
def ml(request):
	return render(request,'ml.html')
def python(request):
	return render(request,'python.html')

def dataShow(request):
	obj=Users.objects.all()
	msg="data<br>"
	for res in obj:
		msg=msg+"<br>"+res.userid
		msg=msg+"<br>"+res.email
	return HttpResponse(msg)


















def btech(request):
	context={'file':FilesAdminBtech.objects.all()}
	return render(request,'btech.html',context)

def download(request,path):
	file_path=os.path.join(settings.MEDIA_ROOT,path)
	if os.path.exists(file_path):
		with open(file_path,'rb')as fh:
			response=HttpResponse(fh.read(),content_type="application/adminupload")
			response['content-Disposition']='inline;filename'+os.path.basename(file_path)
			return response
	raise Http404
	





def diploma(request):
	context={'file':FilesAdminDiploma.objects.all()}
	return render(request,'diploma.html',context)


def download(request,path):
	file_path=os.path.join(settings.MEDIA_ROOT,path)
	if os.path.exists(file_path):
		with open(file_path,'rb')as fh:
			response=HttpResponse(fh.read(),content_type="application/admiinupload")
			response['content-Disposition']='inline;filename'+os.path.basename(file_path)
			return response
	raise Http404		